//
//  Notes_CompleteApp.swift
//  Notes_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct Notes_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
