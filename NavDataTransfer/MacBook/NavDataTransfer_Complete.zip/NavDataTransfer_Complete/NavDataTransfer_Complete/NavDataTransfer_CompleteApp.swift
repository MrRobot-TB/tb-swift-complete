//
//  NavDataTransfer_CompleteApp.swift
//  NavDataTransfer_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct NavDataTransfer_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
