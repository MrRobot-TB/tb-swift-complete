//
//  TempConverter_CompleteApp.swift
//  TempConverter_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct TempConverter_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
