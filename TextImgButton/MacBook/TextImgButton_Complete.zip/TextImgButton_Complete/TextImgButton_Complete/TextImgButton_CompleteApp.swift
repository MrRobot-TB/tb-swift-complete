//
//  TextImgButton_CompleteApp.swift
//  TextImgButton_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct TextImgButton_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
