//
//  HelloWorld_CompleteApp.swift
//  HelloWorld_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct HelloWorld_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
