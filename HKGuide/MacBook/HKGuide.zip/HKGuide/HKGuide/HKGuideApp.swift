//
//  HKGuideApp.swift
//  HKGuide
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct HKGuideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
