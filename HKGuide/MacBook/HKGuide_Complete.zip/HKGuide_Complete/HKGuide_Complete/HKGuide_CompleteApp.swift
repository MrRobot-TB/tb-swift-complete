//
//  HKGuide_CompleteApp.swift
//  HKGuide_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct HKGuide_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
