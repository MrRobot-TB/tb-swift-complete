//
//  Layout_CompleteApp.swift
//  Layout_Complete
//
//  Created by [Redacted]
//

import SwiftUI

@main
struct Layout_CompleteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
